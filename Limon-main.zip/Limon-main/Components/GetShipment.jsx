import React from "react";

const GetShipment = () => {
  return <div>GetShipment</div>;
};

export default GetShipment;
