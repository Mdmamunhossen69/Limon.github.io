import React from "react";

const CompleteShipment = () => {
  return <div>CompleteShipment</div>;
};

export default CompleteShipment;
