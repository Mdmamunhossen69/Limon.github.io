import React from "react";

const StartShipment = () => {
  return <div>StartShipment</div>;
};

export default StartShipment;
